-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2020 at 06:14 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electiondb`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `NAME` varchar(255) NOT NULL,
  `PARTYID` int(255) NOT NULL,
  `CID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`NAME`, `PARTYID`, `CID`) VALUES
('Nebula', 0, '111'),
('Loki', 0, '123'),
('Tony Stark', 1, '123'),
('Nick Fury', 2, '111'),
('Steve Rogers', 2, '321'),
('Peter Parker', 3, '111'),
('Natasha Romanoff', 3, '123'),
('Thor', 4, '321'),
('Stephen Strange', 5, '111'),
('Bruce Banner', 5, '123'),
('Clint Barton', 6, '321'),
('Bucky Barnes', 7, '111'),
('Peter Quill', 8, '111');

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `EPIC` varchar(50) NOT NULL,
  `PARTYID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`EPIC`, `PARTYID`) VALUES
('GDN0225185', 8);

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE `voter` (
  `EPIC` varchar(50) NOT NULL,
  `CID` varchar(50) NOT NULL,
  `VOTED` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`EPIC`, `CID`, `VOTED`) VALUES
('BKA5528102', '123', 0),
('CHA1357901', '321', 0),
('GDN0225185', '111', 1),
('MAS1735128', '111', 0),
('MUA4562113', '321', 0),
('PAA8509112', '123', 0),
('ROR9914721', '111', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`PARTYID`,`CID`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`EPIC`);

--
-- Indexes for table `voter`
--
ALTER TABLE `voter`
  ADD PRIMARY KEY (`EPIC`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
